package com.spring.springmvc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.springmvc.models.Basic_Details;

public interface BasicDetailsRepo extends JpaRepository<Basic_Details, Integer> {

}
