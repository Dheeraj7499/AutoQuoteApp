package com.spring.springmvc.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class ProgressiveDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	private String activePoliciesProgressive;
	
	public ProgressiveDetails() {
		
	}
	
	
	public ProgressiveDetails(int id, String activePoliciesProgressive) {
		super();
		this.id = id;
		this.activePoliciesProgressive = activePoliciesProgressive;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getActivePoliciesProgressive() {
		return activePoliciesProgressive;
	}
	public void setActivePoliciesProgressive(String activePoliciesProgressive) {
		this.activePoliciesProgressive = activePoliciesProgressive;
	}
	
	


	
	

	
	

	
	

	

}
