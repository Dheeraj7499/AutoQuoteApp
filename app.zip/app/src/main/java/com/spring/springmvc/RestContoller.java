package com.spring.springmvc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.springmvc.models.BasicDetails;
import com.spring.springmvc.repo.BasicDetailsRepo;

@RestController
public class RestContoller {
	
	
	
	@Autowired
	BasicDetailsRepo basicdetails;
	
	 /* Adding new vehicle */
    @RequestMapping(value="vehicleprogressive")
    @ResponseBody

    public List<BasicDetails> vehicles_progressive() {
    	
    	List<BasicDetails> vehicle = basicdetails.findAll();
    	
    	return vehicle;
    }
    

    

}
