package com.spring.springmvc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.springmvc.models.ProgressiveDetails;

public interface ProgressiveDetailsRepo extends JpaRepository<ProgressiveDetails, Integer>{
	
}
