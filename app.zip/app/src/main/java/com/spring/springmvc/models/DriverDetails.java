package com.spring.springmvc.models;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class DriverDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int driverId;
	private String driverFirstName;
	private String driverMiddleName;
	private String driverLastName;
	private String driverSuffix;
	private String driverGender;
	private String driverDob;
	private String driverMaritalStatus;
	private String relationshipToDriver1;
	private String driverEducation;
	private String driverEmployementStatus;
	private String driverSsn;
	private String driverResidence;
	private String driverAddress;
	private String driverLicenseStatus; 
	private String driverLicensedYear; 
	private String driverAccidents;
	private String driverAccidentDescription;
	private String driverAccidentHappen;
	private String driverTickets;
	private String driverTicketsDescription;
	private String driverTicketsHappen;
	
	
	//Many driver_details can have only one vehicle_details
	 @ManyToOne
	 @JoinColumn(name = "vehicle_id")
	  private VehicleDetails vehicledetails;
	 
	//One driver_details can have multiple vehicle_details
	 @OneToMany(mappedBy = "driverdetails", cascade = CascadeType.ALL)
	    private List<VehicleDetails> vehicle = new ArrayList<>();
	
	
	public DriverDetails() {
		
	}
	
	
	public DriverDetails(int driverId, String driverFirstName, String driverMiddleName, String driverLastName,
			String driverSuffix, String driverGender, String driverDob, String driverMaritalStatus,
			String relationshipToDriver1, String driverEducation, String driverEmployementStatus, String driverSsn,
			String driverResidence, String driverAddress, String driverLicenseStatus, String driverLicensedYear,
			String driverAccidents, String driverAccidentDescription, String driverAccidentHappen, String driverTickets,
			String driverTicketsDescription, String driverTicketsHappen) {
		super();
		this.driverId = driverId;
		this.driverFirstName = driverFirstName;
		this.driverMiddleName = driverMiddleName;
		this.driverLastName = driverLastName;
		this.driverSuffix = driverSuffix;
		this.driverGender = driverGender;
		this.driverDob = driverDob;
		this.driverMaritalStatus = driverMaritalStatus;
		this.relationshipToDriver1 = relationshipToDriver1;
		this.driverEducation = driverEducation;
		this.driverEmployementStatus = driverEmployementStatus;
		this.driverSsn = driverSsn;
		this.driverResidence = driverResidence;
		this.driverAddress = driverAddress;
		this.driverLicenseStatus = driverLicenseStatus;
		this.driverLicensedYear = driverLicensedYear;
		this.driverAccidents = driverAccidents;
		this.driverAccidentDescription = driverAccidentDescription;
		this.driverAccidentHappen = driverAccidentHappen;
		this.driverTickets = driverTickets;
		this.driverTicketsDescription = driverTicketsDescription;
		this.driverTicketsHappen = driverTicketsHappen;
	}


	public int getDriverId() {
		return driverId;
	}


	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}


	public String getDriverFirstName() {
		return driverFirstName;
	}


	public void setDriverFirstName(String driverFirstName) {
		this.driverFirstName = driverFirstName;
	}


	public String getDriverMiddleName() {
		return driverMiddleName;
	}


	public void setDriverMiddleName(String driverMiddleName) {
		this.driverMiddleName = driverMiddleName;
	}


	public String getDriverLastName() {
		return driverLastName;
	}


	public void setDriverLastName(String driverLastName) {
		this.driverLastName = driverLastName;
	}


	public String getDriverSuffix() {
		return driverSuffix;
	}


	public void setDriverSuffix(String driverSuffix) {
		this.driverSuffix = driverSuffix;
	}


	public String getDriverGender() {
		return driverGender;
	}


	public void setDriverGender(String driverGender) {
		this.driverGender = driverGender;
	}


	public String getDriverDob() {
		return driverDob;
	}


	public void setDriverDob(String driverDob) {
		this.driverDob = driverDob;
	}


	public String getDriverMaritalStatus() {
		return driverMaritalStatus;
	}


	public void setDriverMaritalStatus(String driverMaritalStatus) {
		this.driverMaritalStatus = driverMaritalStatus;
	}


	public String getRelationshipToDriver1() {
		return relationshipToDriver1;
	}


	public void setRelationshipToDriver1(String relationshipToDriver1) {
		this.relationshipToDriver1 = relationshipToDriver1;
	}


	public String getDriverEducation() {
		return driverEducation;
	}


	public void setDriverEducation(String driverEducation) {
		this.driverEducation = driverEducation;
	}


	public String getDriverEmployementStatus() {
		return driverEmployementStatus;
	}


	public void setDriverEmployementStatus(String driverEmployementStatus) {
		this.driverEmployementStatus = driverEmployementStatus;
	}


	public String getDriverSsn() {
		return driverSsn;
	}


	public void setDriverSsn(String driverSsn) {
		this.driverSsn = driverSsn;
	}


	public String getDriverResidence() {
		return driverResidence;
	}


	public void setDriverResidence(String driverResidence) {
		this.driverResidence = driverResidence;
	}


	public String getDriverAddress() {
		return driverAddress;
	}


	public void setDriverAddress(String driverAddress) {
		this.driverAddress = driverAddress;
	}


	public String getDriverLicenseStatus() {
		return driverLicenseStatus;
	}


	public void setDriverLicenseStatus(String driverLicenseStatus) {
		this.driverLicenseStatus = driverLicenseStatus;
	}


	public String getDriverLicensedYear() {
		return driverLicensedYear;
	}


	public void setDriverLicensedYear(String driverLicensedYear) {
		this.driverLicensedYear = driverLicensedYear;
	}


	public String getDriverAccidents() {
		return driverAccidents;
	}


	public void setDriverAccidents(String driverAccidents) {
		this.driverAccidents = driverAccidents;
	}


	public String getDriverAccidentDescription() {
		return driverAccidentDescription;
	}


	public void setDriverAccidentDescription(String driverAccidentDescription) {
		this.driverAccidentDescription = driverAccidentDescription;
	}


	public String getDriverAccidentHappen() {
		return driverAccidentHappen;
	}


	public void setDriverAccidentHappen(String driverAccidentHappen) {
		this.driverAccidentHappen = driverAccidentHappen;
	}


	public String getDriverTickets() {
		return driverTickets;
	}


	public void setDriverTickets(String driverTickets) {
		this.driverTickets = driverTickets;
	}


	public String getDriverTicketsDescription() {
		return driverTicketsDescription;
	}


	public void setDriverTicketsDescription(String driverTicketsDescription) {
		this.driverTicketsDescription = driverTicketsDescription;
	}


	public String getDriverTicketsHappen() {
		return driverTicketsHappen;
	}


	public void setDriverTicketsHappen(String driverTicketsHappen) {
		this.driverTicketsHappen = driverTicketsHappen;
	}




	public VehicleDetails getVehicledetails() {
		return vehicledetails;
	}


	public void setVehicledetails(VehicleDetails vehicledetails) {
		this.vehicledetails = vehicledetails;
	}


	public List<VehicleDetails> getVehicle() {
		return vehicle;
	}


	public void setVehicle(List<VehicleDetails> vehicle) {
		this.vehicle = vehicle;
	}


    
	
	
    

	
    
}
