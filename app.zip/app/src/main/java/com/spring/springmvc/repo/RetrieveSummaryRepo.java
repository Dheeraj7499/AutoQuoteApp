package com.spring.springmvc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.springmvc.models.RetrieveSummary;

public interface RetrieveSummaryRepo extends JpaRepository<RetrieveSummary, Integer> {

}
