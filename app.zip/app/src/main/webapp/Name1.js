window.addEventListener('load', () => {

const zip = sessionStorage.getItem('ZIP');
document.getElementById('pincode').value = zip;

})

