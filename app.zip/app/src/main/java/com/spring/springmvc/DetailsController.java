package com.spring.springmvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.springmvc.models.Basic_Details;
import com.spring.springmvc.models.Driver_Details;
import com.spring.springmvc.models.FinalDetails;
import com.spring.springmvc.models.ProgressiveDetails;
import com.spring.springmvc.models.SnapshotDetails;
import com.spring.springmvc.models.Vehicle_Details;
import com.spring.springmvc.repo.BasicDetailsRepo;
import com.spring.springmvc.repo.DriverRepository;
import com.spring.springmvc.repo.FinalDetailsRepo;
import com.spring.springmvc.repo.ProgressiveDetailsRepo;
import com.spring.springmvc.repo.SnapshotDetailsRepo;
import com.spring.springmvc.repo.VehicleRepository;

@Controller /* specifies that this is a controller*/
public class DetailsController {
	
	   @Autowired
	   BasicDetailsRepo basicdetails;
	   @Autowired
	   DriverRepository driverrepo;
	   @Autowired
	   VehicleRepository vehiclerepo;
	   @Autowired
	   SnapshotDetailsRepo snapshot;
	   @Autowired
	   FinalDetailsRepo finaldetails;
	   @Autowired
	   ProgressiveDetailsRepo progressivedetails;
	   
	
	
	    @RequestMapping(value ="/")
		public String home() {
			return "Starting_Page.html";
		}
	    
	    /*basic_details of a person */
	    @RequestMapping(value ="add")
	    public String name_progressive() {
	    	return "Name.html";
	    }
	    
	    /* Adding new vehicle */
	    @RequestMapping(value="vehicle")
	    public String vehicles_progressive(@ModelAttribute Basic_Details d) {
	    	basicdetails.save(d);
	    	return "VehiclesNew.html";
	    }
	    
	    /* Editing the vehicle */
	    @RequestMapping(value ="vehicleedit")
	    public String vehicles_edit_progressive() {
	    	
	    	return "VehiclesEdit.html";
	    }
	    /* Removing the vehicle */
	    @RequestMapping(value ="vehicleremove")
	    public String vehicles_remove_progreesive(@ModelAttribute Vehicle_Details vd) {
	    	vehiclerepo.save(vd);
	    	return "VehiclesAllEdit.html";
	    }
	    
	    /* Adding the Driver */
	    @RequestMapping(value ="driver")
	    public String driver_progressive() {
	    	
	    	return "DriverDetails.html";
	    }
	    
	    /*driver confirmation */
	    @RequestMapping(value ="driverconformation")
	    public String driver_conformation_progressive(@ModelAttribute Driver_Details dd) {
	    	driverrepo.save(dd);
	    	return "DriverConformation.html";
	    }    
	    
	    
	    /*final details */
	    @RequestMapping(value ="finaldetails")
	    public String final_details_progressive() {
	    	return "FinalDetails.html";
	    } 
	    
	    /*other progressive details */
	    @RequestMapping(value ="otherdetails")
	    public String other_details_progressive(@ModelAttribute FinalDetails fd) {
	    	finaldetails.save(fd);
	    	return "ProgressiveDetails.html";
	    }
	    
	    /*snapshot details */
	    @RequestMapping(value ="snapshotdetails")
	    public String snapshot_details_progressive(@ModelAttribute ProgressiveDetails pd) {
	    	progressivedetails.save(pd);
	    	return "Snapshot.html";
	    } 
	    
	    @RequestMapping(value = "home")
	    public String homepage(@ModelAttribute SnapshotDetails sd) 
	    {
	    	snapshot.save(sd);
	    	return "Starting_Page.html";
	    }
	    
}
