package com.spring.springmvc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.springmvc.models.DriverDetails;




public interface DriverRepository extends JpaRepository<DriverDetails, Integer>{

}
