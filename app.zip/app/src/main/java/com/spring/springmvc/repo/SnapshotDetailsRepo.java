package com.spring.springmvc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.springmvc.models.SnapshotDetails;

public interface SnapshotDetailsRepo extends JpaRepository<SnapshotDetails, Integer> {

}
