package com.spring.springmvc.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class ProgressiveDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	private String active_policies_progressive;
	@ManyToOne
	private Basic_Details basic_details;
	
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getActive_policies_progressive() {
		return active_policies_progressive;
	}
	public void setActive_policies_progressive(String active_policies_progressive) {
		this.active_policies_progressive = active_policies_progressive;
	}
	public Basic_Details getBasic_details() {
		return basic_details;
	}
	public void setBasic_details(Basic_Details basic_details) {
		this.basic_details = basic_details;
	}
	
	

	

}
