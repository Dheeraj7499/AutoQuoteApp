package com.spring.springmvc.models;





import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;


@Entity
public class SnapshotDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private Long id;
	private String startSavings; //null
	private String enrollementOptionsSavings;
	
	@OneToOne
	@JoinColumn(name="basic_id")
    private BasicDetails basicdetails;
	
	
	public SnapshotDetails() {
		
	}




	public SnapshotDetails(Long id, String startSavings, String enrollementOptionsSavings) {
		super();
		this.id = id;
		this.startSavings = startSavings;
		this.enrollementOptionsSavings = enrollementOptionsSavings;
	}




	public Long getId() {
		return id;
	}




	public void setId(Long id) {
		this.id = id;
	}




	public String getStartSavings() {
		return startSavings;
	}




	public void setStartSavings(String startSavings) {
		this.startSavings = startSavings;
	}




	public String getEnrollementOptionsSavings() {
		return enrollementOptionsSavings;
	}




	public void setEnrollementOptionsSavings(String enrollementOptionsSavings) {
		this.enrollementOptionsSavings = enrollementOptionsSavings;
	}




	public BasicDetails getBasicdetails() {
		return basicdetails;
	}




	public void setBasicdetails(BasicDetails basicdetails) {
		this.basicdetails = basicdetails;
	}




	

    
	

}
