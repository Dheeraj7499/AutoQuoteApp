package com.spring.springmvc.models;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class BasicDetails {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;
	
	private String firstName;
	private String middleName;
	private String lastName;
	private String suffix;
	private String mailingAddess;
	private String aptNumber;
	private String city;
	private String state;
	private int zipcode;
	private String gender;
	private String pobox;
	
	@OneToOne(mappedBy = "basicdetails", cascade = CascadeType.ALL)
	private SnapshotDetails snapshot;
	
	

	


	public BasicDetails() {
		
	}


	public BasicDetails(Long id, String firstName, String middleName, String lastName, String suffix,
			String mailingAddess, String aptNumber, String city, String state, int zipcode, String gender, String pobox
			) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.suffix = suffix;
		this.mailingAddess = mailingAddess;
		this.aptNumber = aptNumber;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
		this.gender = gender;
		this.pobox = pobox;
		
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getMiddleName() {
		return middleName;
	}


	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getSuffix() {
		return suffix;
	}


	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}


	public String getMailingAddess() {
		return mailingAddess;
	}


	public void setMailingAddess(String mailingAddess) {
		this.mailingAddess = mailingAddess;
	}


	public String getAptNumber() {
		return aptNumber;
	}


	public void setAptNumber(String aptNumber) {
		this.aptNumber = aptNumber;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public int getZipcode() {
		return zipcode;
	}


	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getPobox() {
		return pobox;
	}


	public void setPobox(String pobox) {
		this.pobox = pobox;
	}


	public SnapshotDetails getSnapshot() {
		return snapshot;
	}


	public void setSnapshot(SnapshotDetails snapshot) {
		this.snapshot = snapshot;
	}


     
	
    
	

	
	
	
}
