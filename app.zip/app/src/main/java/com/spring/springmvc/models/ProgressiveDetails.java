package com.spring.springmvc.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class ProgressiveDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	private String active_policies_progressive;
	
	@OneToMany
	private Basic_Details basic_deatils;
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	public String getActive_policies_progressive() {
		return active_policies_progressive;
	}
	public void setActive_policies_progressive(String active_policies_progressive) {
		this.active_policies_progressive = active_policies_progressive;
	}
	public Basic_Details getBasic_deatils() {
		return basic_deatils;
	}
	public void setBasic_deatils(Basic_Details basic_deatils) {
		this.basic_deatils = basic_deatils;
	}
	
	

	
	

	

}
