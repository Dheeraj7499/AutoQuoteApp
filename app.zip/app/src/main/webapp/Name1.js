window.addEventListener('load', () => {

const zip = sessionStorage.getItem('ZIP');
document.getElementById('pincode').value = zip;

})

function handleSubmit1() {
    const firstname = document.getElementById('firstname').value;
    sessionStorage.setItem("FirstName", firstname);
    return;
    

}

function handleMiddleName(){
	const middlename = document.getElementById('middlename').value;
    sessionStorage.setItem("MiddleName", middlename);
    return;
}

function handleLastName(){
	const lastname = document.getElementById('lastname').value;
    sessionStorage.setItem("LastName", lastname);
    return;
}

function handleAddress() {
    const address = document.getElementById('addressmust').value;
    sessionStorage.setItem("Address", address);
    return;
    

}

function runMultipleFunctions(){
	handleSubmit1();
	handleMiddleName();
	handleLastName();
	handleAddress();
}

