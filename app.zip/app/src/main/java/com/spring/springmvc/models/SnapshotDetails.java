package com.spring.springmvc.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class SnapshotDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	private String start_savings;
	private String enrollement_options_savings;
	
	@OneToOne()
	@JoinColumn(name="basicdetails_id" )
	private Basic_Details basicdetails;
	
	
	public SnapshotDetails() {
		
	}


	public SnapshotDetails(int id, String start_savings, String enrollement_options_savings,
			Basic_Details basicdetails) {
		super();
		this.id = id;
		this.start_savings = start_savings;
		this.enrollement_options_savings = enrollement_options_savings;
		this.basicdetails = basicdetails;
	}







	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getStart_savings() {
		return start_savings;
	}



	public void setStart_savings(String start_savings) {
		this.start_savings = start_savings;
	}



	public String getEnrollement_options_savings() {
		return enrollement_options_savings;
	}



	public void setEnrollement_options_savings(String enrollement_options_savings) {
		this.enrollement_options_savings = enrollement_options_savings;
	}


	public Basic_Details getBasicdetails() {
		return basicdetails;
	}


	public void setBasicdetails(Basic_Details basicdetails) {
		this.basicdetails = basicdetails;
	}








	
	


	
    



    
	
	

}
