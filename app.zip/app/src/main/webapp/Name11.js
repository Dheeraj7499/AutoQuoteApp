	function validation(){
	var nameinput = document.getElementById('firstname');
	var nameError = document.getElementById('nameError');
	var namePattern = /^[A-Za-z\s]+$/;
	var isValid = true;
	  if (!namePattern.test(nameInput.value)) {
                nameError.textContent = "Invalid name. Please enter a valid name.";
                isValid = false;
            } else {
                nameError.textContent = "";
            }
      }