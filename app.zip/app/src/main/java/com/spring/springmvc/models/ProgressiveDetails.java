package com.spring.springmvc.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class ProgressiveDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	private String activePoliciesProgressive;
	
	//One Final_Details can have only one basic_details
    @OneToOne
	@JoinColumn(name="basic_id")
	private BasicDetails basicdetails;
	
	public ProgressiveDetails() {
		
	}
	
	
	public ProgressiveDetails(int id, String activePoliciesProgressive) {
		super();
		this.id = id;
		this.activePoliciesProgressive = activePoliciesProgressive;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getActivePoliciesProgressive() {
		return activePoliciesProgressive;
	}
	public void setActivePoliciesProgressive(String activePoliciesProgressive) {
		this.activePoliciesProgressive = activePoliciesProgressive;
	}


	public BasicDetails getBasicdetails() {
		return basicdetails;
	}


	public void setBasicdetails(BasicDetails basicdetails) {
		this.basicdetails = basicdetails;
	}
	
	

    
	
	

	
	

	
	

	

}
