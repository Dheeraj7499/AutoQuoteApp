package com.spring.springmvc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.springmvc.models.Driver_Details;

public interface DriverRepository extends JpaRepository<Driver_Details, Integer>{

}
