package com.spring.springmvc.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class FinalDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;
	private String existingAutoInsurance;
	private String yearsLongExistingInsurance;
	private String currentBodilyInjuryLimits;
	private String nonAutoPoliciesProgressive;
	private String autoInsuranceProgressiveLastMonth;
	private String reasonQuotingNewPolicy;
	private String residentsInHome;
	private String email;
	
	

	
	public FinalDetails() {
		
	}




	public FinalDetails(Long id, String existingAutoInsurance, String yearsLongExistingInsurance,
			String currentBodilyInjuryLimits, String nonAutoPoliciesProgressive,
			String autoInsuranceProgressiveLastMonth, String reasonQuotingNewPolicy, String residentsInHome,
			String email) {
		super();
		this.id = id;
		this.existingAutoInsurance = existingAutoInsurance;
		this.yearsLongExistingInsurance = yearsLongExistingInsurance;
		this.currentBodilyInjuryLimits = currentBodilyInjuryLimits;
		this.nonAutoPoliciesProgressive = nonAutoPoliciesProgressive;
		this.autoInsuranceProgressiveLastMonth = autoInsuranceProgressiveLastMonth;
		this.reasonQuotingNewPolicy = reasonQuotingNewPolicy;
		this.residentsInHome = residentsInHome;
		this.email = email;
	}




	public Long getId() {
		return id;
	}




	public void setId(Long id) {
		this.id = id;
	}




	public String getExistingAutoInsurance() {
		return existingAutoInsurance;
	}




	public void setExistingAutoInsurance(String existingAutoInsurance) {
		this.existingAutoInsurance = existingAutoInsurance;
	}




	public String getYearsLongExistingInsurance() {
		return yearsLongExistingInsurance;
	}




	public void setYearsLongExistingInsurance(String yearsLongExistingInsurance) {
		this.yearsLongExistingInsurance = yearsLongExistingInsurance;
	}




	public String getCurrentBodilyInjuryLimits() {
		return currentBodilyInjuryLimits;
	}




	public void setCurrentBodilyInjuryLimits(String currentBodilyInjuryLimits) {
		this.currentBodilyInjuryLimits = currentBodilyInjuryLimits;
	}




	public String getNonAutoPoliciesProgressive() {
		return nonAutoPoliciesProgressive;
	}




	public void setNonAutoPoliciesProgressive(String nonAutoPoliciesProgressive) {
		this.nonAutoPoliciesProgressive = nonAutoPoliciesProgressive;
	}




	public String getAutoInsuranceProgressiveLastMonth() {
		return autoInsuranceProgressiveLastMonth;
	}




	public void setAutoInsuranceProgressiveLastMonth(String autoInsuranceProgressiveLastMonth) {
		this.autoInsuranceProgressiveLastMonth = autoInsuranceProgressiveLastMonth;
	}




	public String getReasonQuotingNewPolicy() {
		return reasonQuotingNewPolicy;
	}




	public void setReasonQuotingNewPolicy(String reasonQuotingNewPolicy) {
		this.reasonQuotingNewPolicy = reasonQuotingNewPolicy;
	}




	public String getResidentsInHome() {
		return residentsInHome;
	}




	public void setResidentsInHome(String residentsInHome) {
		this.residentsInHome = residentsInHome;
	}




	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}
    
	
	
	
}		
		