function handleSubmit () {
    const zipcode = document.getElementById('zipcode').value;
    sessionStorage.setItem("ZIP", zipcode);
    return;
}