package com.spring.springmvc.models;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;

@Entity
public class VehicleDetails { //table_name
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int vehicleId; 
	
	private String vehicleYear; //column name
	private String vehicleMake;
	private String vehicleModel;
	private String vehicleUse; 
	private String vehicleBusinessUse;
	private String vehicleZip;
	private String vehicleOwnership;
	private String vehicleOwnedYears;
	private String vehicleBlindsopt;
	
	
	public VehicleDetails() {
		
	}
	
	public VehicleDetails(int vehicleId, String vehicleYear, String vehicleMake, String vehicleModel, String vehicleUse,
			String vehicleBusinessUse, String vehicleZip, String vehicleOwnership, String vehicleOwnedYears,
			String vehicleBlindsopt) {
		super();
		this.vehicleId = vehicleId;
		this.vehicleYear = vehicleYear;
		this.vehicleMake = vehicleMake;
		this.vehicleModel = vehicleModel;
		this.vehicleUse = vehicleUse;
		this.vehicleBusinessUse = vehicleBusinessUse;
		this.vehicleZip = vehicleZip;
		this.vehicleOwnership = vehicleOwnership;
		this.vehicleOwnedYears = vehicleOwnedYears;
		this.vehicleBlindsopt = vehicleBlindsopt;
	}


	public int getVehicleId() {
		return vehicleId;
	}


	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}


	public String getVehicleYear() {
		return vehicleYear;
	}


	public void setVehicleYear(String vehicleYear) {
		this.vehicleYear = vehicleYear;
	}


	public String getVehicleMake() {
		return vehicleMake;
	}


	public void setVehicleMake(String vehicleMake) {
		this.vehicleMake = vehicleMake;
	}


	public String getVehicleModel() {
		return vehicleModel;
	}


	public void setVehicleModel(String vehicleModel) {
		this.vehicleModel = vehicleModel;
	}


	public String getVehicleUse() {
		return vehicleUse;
	}


	public void setVehicleUse(String vehicleUse) {
		this.vehicleUse = vehicleUse;
	}


	public String getVehicleBusinessUse() {
		return vehicleBusinessUse;
	}


	public void setVehicleBusinessUse(String vehicleBusinessUse) {
		this.vehicleBusinessUse = vehicleBusinessUse;
	}


	public String getVehicleZip() {
		return vehicleZip;
	}


	public void setVehicleZip(String vehicleZip) {
		this.vehicleZip = vehicleZip;
	}


	public String getVehicleOwnership() {
		return vehicleOwnership;
	}


	public void setVehicleOwnership(String vehicleOwnership) {
		this.vehicleOwnership = vehicleOwnership;
	}


	public String getVehicleOwnedYears() {
		return vehicleOwnedYears;
	}


	public void setVehicleOwnedYears(String vehicleOwnedYears) {
		this.vehicleOwnedYears = vehicleOwnedYears;
	}


	public String getVehicleBlindsopt() {
		return vehicleBlindsopt;
	}


	public void setVehicleBlindsopt(String vehicleBlindsopt) {
		this.vehicleBlindsopt = vehicleBlindsopt;
	}
	
	
	


	
	
	
}
