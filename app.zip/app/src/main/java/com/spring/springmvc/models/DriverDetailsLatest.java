/*package com.spring.springmvc.models;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity(name="DriverDetails")
public class DriverDetailsLatest {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int driver_id;
	private String driver_first_name;
	private String driver_middle_name;
	private String driver_last_name;
	private String driver_suffix;
	private String driver_gender;
	private String driver_dob;
	private String driver_marital_status;
	private String relationship_to_driver1;
	private String driver_education;
	private String driver_employement_status;
	private String driver_ssn;
	private String driver_residence; 
	private String driver_address;
	private String driver_license_status; 
	private String driver_licensed_year; 
	private String driver_accidents;
	public int getDriver_id() {
		return driver_id;
	}

	public void setDriver_id(int driver_id) {
		this.driver_id = driver_id;
	}

	public String getDriver_first_name() {
		return driver_first_name;
	}

	public void setDriver_first_name(String driver_first_name) {
		this.driver_first_name = driver_first_name;
	}

	public String getDriver_middle_name() {
		return driver_middle_name;
	}

	public void setDriver_middle_name(String driver_middle_name) {
		this.driver_middle_name = driver_middle_name;
	}

	public String getDriver_last_name() {
		return driver_last_name;
	}

	public void setDriver_last_name(String driver_last_name) {
		this.driver_last_name = driver_last_name;
	}

	public String getDriver_suffix() {
		return driver_suffix;
	}

	public void setDriver_suffix(String driver_suffix) {
		this.driver_suffix = driver_suffix;
	}

	public String getDriver_gender() {
		return driver_gender;
	}

	public void setDriver_gender(String driver_gender) {
		this.driver_gender = driver_gender;
	}

	public String getDriver_dob() {
		return driver_dob;
	}

	public void setDriver_dob(String driver_dob) {
		this.driver_dob = driver_dob;
	}

	public String getDriver_marital_status() {
		return driver_marital_status;
	}

	public void setDriver_marital_status(String driver_marital_status) {
		this.driver_marital_status = driver_marital_status;
	}

	public String getRelationship_to_driver1() {
		return relationship_to_driver1;
	}

	public void setRelationship_to_driver1(String relationship_to_driver1) {
		this.relationship_to_driver1 = relationship_to_driver1;
	}

	public String getDriver_education() {
		return driver_education;
	}

	public void setDriver_education(String driver_education) {
		this.driver_education = driver_education;
	}

	public String getDriver_employement_status() {
		return driver_employement_status;
	}

	public void setDriver_employement_status(String driver_employement_status) {
		this.driver_employement_status = driver_employement_status;
	}

	public String getDriver_ssn() {
		return driver_ssn;
	}

	public void setDriver_ssn(String driver_ssn) {
		this.driver_ssn = driver_ssn;
	}

	public String getDriver_residence() {
		return driver_residence;
	}

	public void setDriver_residence(String driver_residence) {
		this.driver_residence = driver_residence;
	}

	public String getDriver_address() {
		return driver_address;
	}

	public void setDriver_address(String driver_address) {
		this.driver_address = driver_address;
	}

	public String getDriver_license_status() {
		return driver_license_status;
	}

	public void setDriver_license_status(String driver_license_status) {
		this.driver_license_status = driver_license_status;
	}

	public String getDriver_licensed_year() {
		return driver_licensed_year;
	}

	public void setDriver_licensed_year(String driver_licensed_year) {
		this.driver_licensed_year = driver_licensed_year;
	}

	public String getDriver_accidents() {
		return driver_accidents;
	}

	public void setDriver_accidents(String driver_accidents) {
		this.driver_accidents = driver_accidents;
	}

	public String getDriver_accident_description() {
		return driver_accident_description;
	}

	public void setDriver_accident_description(String driver_accident_description) {
		this.driver_accident_description = driver_accident_description;
	}

	public String getDriver_accident_happen() {
		return driver_accident_happen;
	}

	public void setDriver_accident_happen(String driver_accident_happen) {
		this.driver_accident_happen = driver_accident_happen;
	}

	public String getDriver_tickets() {
		return driver_tickets;
	}

	public void setDriver_tickets(String driver_tickets) {
		this.driver_tickets = driver_tickets;
	}

	public String getDriver_tickets_description() {
		return driver_tickets_description;
	}

	public void setDriver_tickets_description(String driver_tickets_description) {
		this.driver_tickets_description = driver_tickets_description;
	}

	public String getDriver_tickets_happen() {
		return driver_tickets_happen;
	}

	public void setDriver_tickets_happen(String driver_tickets_happen) {
		this.driver_tickets_happen = driver_tickets_happen;
	}

	public BasicDetailsLatest getDriverDetailsLatest() {
		return driverDetailsLatest;
	}

	public void setDriverDetailsLatest(BasicDetailsLatest driverDetailsLatest) {
		this.driverDetailsLatest = driverDetailsLatest;
	}

	private String driver_accident_description;
	private String driver_accident_happen;
	private String driver_tickets;
	private String driver_tickets_description;
	private String driver_tickets_happen;
	
	@ManyToOne
	@JoinColumn(name="driverDetailsLatest_ID")
	private BasicDetailsLatest driverDetailsLatest;
} */
