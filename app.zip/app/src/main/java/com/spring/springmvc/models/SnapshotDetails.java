package com.spring.springmvc.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class SnapshotDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	private String start_savings;
	private String enrollement_options_savings;
	
	@ManyToOne
	private Basic_Details basic_details;
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStart_savings() {
		return start_savings;
	}

	public void setStart_savings(String start_savings) {
		this.start_savings = start_savings;
	}

	public String getEnrollement_options_savings() {
		return enrollement_options_savings;
	}

	public void setEnrollement_options_savings(String enrollement_options_savings) {
		this.enrollement_options_savings = enrollement_options_savings;
	}

	public Basic_Details getBasic_details() {
		return basic_details;
	}

	public void setBasic_details(Basic_Details basic_details) {
		this.basic_details = basic_details;
	}

    
	
	

}
