package com.spring.springmvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.springmvc.models.Basic_Details;
import com.spring.springmvc.models.Vehicle_Details;
import com.spring.springmvc.repo.BasicDetailsRepo;
import com.spring.springmvc.repo.DriverRepository;
import com.spring.springmvc.repo.VehicleRepository;

@Controller /* specifies that this is a controller*/
public class DetailsController {
	
	   @Autowired
	   BasicDetailsRepo basicdetails;
	   DriverRepository driverrepo;
	   VehicleRepository vehiclerepo;
	
	
	    @RequestMapping(value ="/")
		public String home() {
			return "Starting_Page.html";
		}
	    
	    /*basic_details of a person */
	    @RequestMapping(value ="add")
	    public String name_progressive() {
	    	return "Name.html";
	    }
	    
	    /* Adding new vehicle */
	    @RequestMapping(value="vehicle")
	    public String vehicles_progressive(@ModelAttribute Basic_Details d) {
	    	basicdetails.save(d);
	    	return "VehiclesNew.html";
	    }
	    
	    /* Editing the vehicle */
	    @RequestMapping(value ="vehicleedit")
	    public String vehicles_edit_progressive() {
	    	return "VehiclesEdit.html";
	    }
	    /* Removing the vehicle */
	    @RequestMapping(value ="vehicleremove")
	    public String vehicles_remove_progreesive() {
	    	return "VehiclesAllEdit.html";
	    }
	    
	    /* Adding the Driver */
	    @RequestMapping(value ="driver")
	    public String driver_progressive(@ModelAttribute Vehicle_Details vd) {
	    	vehiclerepo.save(vd); 
	    	return "DriverDetails.html";
	    }
	    
	    /*driver conformation */
	    @RequestMapping(value ="driverconformation")
	    public String driver_conformation_progressive() {
	    	return "DriverConformation.html";
	    }    
	    
	    
	    /*final details */
	    @RequestMapping(value ="finaldetails")
	    public String final_details_progressive() {
	    	return "FinalDetails.html";
	    } 
	    
	    /*other progressive details */
	    @RequestMapping(value ="otherdetails")
	    public String other_details_progressive() {
	    	return "ProgressiveDetails.html";
	    }
	    
	    /*snapshot details */
	    @RequestMapping(value ="snapshotdetails")
	    public String snapshot_details_progressive() {
	    	return "Snapshot.html";
	    } 
	    
	  
	    
}
