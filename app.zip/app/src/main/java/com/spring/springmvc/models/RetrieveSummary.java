package com.spring.springmvc.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity
public class RetrieveSummary {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long retrieve_id;
	private String retrieve_existing_auto_insurance;
	private String retrieve_years_long_existing_insurance;
	private String retrieve_current_bodily_injury_limits;
	private String retrieve_non_auto_policies_progressive;
	private String retrieve_auto_insurance_progressive_last_month;
	private String retrieve_reason_quoting_new_policy;
	private String retrieve_residents_in_home;
	private String retrieve_email;
	
	
	public RetrieveSummary(Long retrieve_id, String retrieve_existing_auto_insurance,
			String retrieve_years_long_existing_insurance, String retrieve_current_bodily_injury_limits,
			String retrieve_non_auto_policies_progressive, String retrieve_auto_insurance_progressive_last_month,
			String retrieve_reason_quoting_new_policy, String retrieve_residents_in_home, String retrieve_email) {
		super();
		this.retrieve_id = retrieve_id;
		this.retrieve_existing_auto_insurance = retrieve_existing_auto_insurance;
		this.retrieve_years_long_existing_insurance = retrieve_years_long_existing_insurance;
		this.retrieve_current_bodily_injury_limits = retrieve_current_bodily_injury_limits;
		this.retrieve_non_auto_policies_progressive = retrieve_non_auto_policies_progressive;
		this.retrieve_auto_insurance_progressive_last_month = retrieve_auto_insurance_progressive_last_month;
		this.retrieve_reason_quoting_new_policy = retrieve_reason_quoting_new_policy;
		this.retrieve_residents_in_home = retrieve_residents_in_home;
		this.retrieve_email = retrieve_email;
	}


	public Long getRetrieve_id() {
		return retrieve_id;
	}


	public void setRetrieve_id(Long retrieve_id) {
		this.retrieve_id = retrieve_id;
	}


	public String getRetrieve_existing_auto_insurance() {
		return retrieve_existing_auto_insurance;
	}


	public void setRetrieve_existing_auto_insurance(String retrieve_existing_auto_insurance) {
		this.retrieve_existing_auto_insurance = retrieve_existing_auto_insurance;
	}


	public String getRetrieve_years_long_existing_insurance() {
		return retrieve_years_long_existing_insurance;
	}


	public void setRetrieve_years_long_existing_insurance(String retrieve_years_long_existing_insurance) {
		this.retrieve_years_long_existing_insurance = retrieve_years_long_existing_insurance;
	}


	public String getRetrieve_current_bodily_injury_limits() {
		return retrieve_current_bodily_injury_limits;
	}


	public void setRetrieve_current_bodily_injury_limits(String retrieve_current_bodily_injury_limits) {
		this.retrieve_current_bodily_injury_limits = retrieve_current_bodily_injury_limits;
	}


	public String getRetrieve_non_auto_policies_progressive() {
		return retrieve_non_auto_policies_progressive;
	}


	public void setRetrieve_non_auto_policies_progressive(String retrieve_non_auto_policies_progressive) {
		this.retrieve_non_auto_policies_progressive = retrieve_non_auto_policies_progressive;
	}


	public String getRetrieve_auto_insurance_progressive_last_month() {
		return retrieve_auto_insurance_progressive_last_month;
	}


	public void setRetrieve_auto_insurance_progressive_last_month(String retrieve_auto_insurance_progressive_last_month) {
		this.retrieve_auto_insurance_progressive_last_month = retrieve_auto_insurance_progressive_last_month;
	}


	public String getRetrieve_reason_quoting_new_policy() {
		return retrieve_reason_quoting_new_policy;
	}


	public void setRetrieve_reason_quoting_new_policy(String retrieve_reason_quoting_new_policy) {
		this.retrieve_reason_quoting_new_policy = retrieve_reason_quoting_new_policy;
	}


	public String getRetrieve_residents_in_home() {
		return retrieve_residents_in_home;
	}


	public void setRetrieve_residents_in_home(String retrieve_residents_in_home) {
		this.retrieve_residents_in_home = retrieve_residents_in_home;
	}


	public String getRetrieve_email() {
		return retrieve_email;
	}


	public void setRetrieve_email(String retrieve_email) {
		this.retrieve_email = retrieve_email;
	}


	@Override
	public String toString() {
		return "RetrieveSummary [retrieve_id=" + retrieve_id + ", retrieve_existing_auto_insurance="
				+ retrieve_existing_auto_insurance + ", retrieve_years_long_existing_insurance="
				+ retrieve_years_long_existing_insurance + ", retrieve_current_bodily_injury_limits="
				+ retrieve_current_bodily_injury_limits + ", retrieve_non_auto_policies_progressive="
				+ retrieve_non_auto_policies_progressive + ", retrieve_auto_insurance_progressive_last_month="
				+ retrieve_auto_insurance_progressive_last_month + ", retrieve_reason_quoting_new_policy="
				+ retrieve_reason_quoting_new_policy + ", retrieve_residents_in_home=" + retrieve_residents_in_home
				+ ", retrieve_email=" + retrieve_email + "]";
	}
	
	
	
	

}
