package com.spring.springmvc;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;

import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.springmvc.models.BasicDetails;
import com.spring.springmvc.models.DriverDetails;
import com.spring.springmvc.models.FinalDetails;
import com.spring.springmvc.models.ProgressiveDetails;
import com.spring.springmvc.models.SnapshotDetails;
import com.spring.springmvc.models.VehicleDetails;
import com.spring.springmvc.repo.BasicDetailsRepo;
import com.spring.springmvc.repo.DriverRepository;
import com.spring.springmvc.repo.FinalDetailsRepo;
import com.spring.springmvc.repo.ProgressiveDetailsRepo;
import com.spring.springmvc.repo.SnapshotDetailsRepo;
import com.spring.springmvc.repo.VehicleRepository;


import jakarta.persistence.EntityNotFoundException;

@Controller /* specifies that this is a controller*/
@Service
public class DetailsController {
	
	   @Autowired
	   BasicDetailsRepo basicdetails;
	   @Autowired
	   DriverRepository driverrepo;
	   @Autowired
	   VehicleRepository vehiclerepo;
	   @Autowired
	   SnapshotDetailsRepo snapshot;
	   @Autowired
	   FinalDetailsRepo finaldetails;
	   @Autowired
	   ProgressiveDetailsRepo progressivedetails;
	   public static Long bdid=0l;
	
	
	    @RequestMapping(value ="/")
		public String home() {
			return "Starting_Page.html";
		}
	    
	    /*basic_details of a person */
	    @RequestMapping("/add")
	    public String nameProgressive() {
	    	return "Name.html";
	    }
	    
	    /* Adding new vehicle */
	    @RequestMapping(value="vehicle")
	    public String vehiclesProgressive(@ModelAttribute BasicDetails d) {
	    	
	    	
	    	
	    	BasicDetails bd =basicdetails.save(d);
	    	// System.out.println(bd.getId());
	    	 
	    	bdid= bd.getId();
	    	return "VehiclesNew.html";
	    }
	    
	    /* Editing the vehicle */
	    @RequestMapping(value ="vehicleedit")
	    public String vehiclesEditProgressive() {
	    	
	    	return "VehiclesEdit.html";
	    }
	    /* Removing the vehicle */
	    @RequestMapping(value ="vehicleremove")
	    public String vehiclesRemoveProgreesive(@ModelAttribute VehicleDetails vd) {
	    	vehiclerepo.save(vd);
	    	return "VehiclesAllEdit.html";
	    }
	    
	    /* Adding the Driver */
	    @RequestMapping(value ="driver")
	    public String driverProgressive() {
	    	
	    	return "DriverDetails.html";
	    }
	    
	    /*driver confirmation */
	    @RequestMapping(value ="driverconformation")
	    public String driverConformationProgressive(@ModelAttribute DriverDetails dd) {
	    	driverrepo.save(dd);
	    	return "DriverConformation.html";
	    }    
	    
	    
	    /*final details */
	    @RequestMapping(value ="finaldetails")
	    public String finalDetailsProgressive() {
	    	return "FinalDetails.html";
	    } 
	    
	    /*other progressive details */
	    @RequestMapping(value ="otherdetails")
	    public String otherDetailsProgressive(@ModelAttribute FinalDetails fd ) 
	    {
	    	Optional<BasicDetails> bd = basicdetails.findById(bdid);
	    	BasicDetails b = bd.get();
	    	fd.setBasicdetails(b);
	    	b.setFinaldetails(fd);
	        basicdetails.save(b);
	    	return "ProgressiveDetails.html";
	    }
	    
	    /*snapshot details */
	    @RequestMapping(value ="snapshotdetails")
	    public String snapshotDetailsProgressive(@ModelAttribute ProgressiveDetails pd) {
	    	Optional<BasicDetails> bd = basicdetails.findById(bdid);
	    	BasicDetails b = bd.get();
	    	pd.setBasicdetails(b);
	    	b.setProgressivedetails(pd);
	        basicdetails.save(b);
	    	return "Snapshot.html";
	    } 
	    
	    @RequestMapping(value = "home")
	    public String homePage( @ModelAttribute SnapshotDetails sd) 
	    {
	    	Optional<BasicDetails> bd = basicdetails.findById(bdid);
	        BasicDetails b = bd.get();
	       // System.out.println(b);
	        sd.setBasicdetails(b);
	    	b.setSnapshot(sd);
	    	basicdetails.save(b);
	    	return "Starting_Page.html";
	    }
	    
}
