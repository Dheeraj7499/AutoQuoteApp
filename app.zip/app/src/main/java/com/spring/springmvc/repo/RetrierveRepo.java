package com.spring.springmvc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.springmvc.models.RetriveDetails;

public interface RetrierveRepo extends JpaRepository<RetriveDetails, Integer>{

}
