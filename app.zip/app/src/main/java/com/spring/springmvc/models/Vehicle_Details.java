package com.spring.springmvc.models;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;

@Entity
public class Vehicle_Details { //table_name
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int vehicle_id; 
	
	private String vehicle_year; //column name
	private String vehicle_make;
	private String vehicle_model;
	private String vehicle_use; 
	private String vehicle_business_use;
	private String vehicle_zip;
	private String vehicle_ownership;
	private String vehicle_owned_years;
	private String vehicle_blindsopt;
	
	
	@ManyToMany 
	@JoinTable(name = "vehicle",
		joinColumns = {@JoinColumn(name = "vehicle_id")},
		inverseJoinColumns = {@JoinColumn(name = "driver_id")} )
	private List<Driver_Details> driver = new ArrayList<Driver_Details>();


	public int getVehicle_id() {
		return vehicle_id;
	}
    

	public void setVehicle_id(int vehicle_id) {
		this.vehicle_id = vehicle_id;
	}


	public String getVehicle_year() {
		return vehicle_year;
	}


	public void setVehicle_year(String vehicle_year) {
		this.vehicle_year = vehicle_year;
	}


	public String getVehicle_make() {
		return vehicle_make;
	}


	public void setVehicle_make(String vehicle_make) {
		this.vehicle_make = vehicle_make;
	}


	public String getVehicle_model() {
		return vehicle_model;
	}


	public void setVehicle_model(String vehicle_model) {
		this.vehicle_model = vehicle_model;
	}


	public String getVehicle_use() {
		return vehicle_use;
	}


	public void setVehicle_use(String vehicle_use) {
		this.vehicle_use = vehicle_use;
	}
    
	

	public String getVehicle_business_use() {
		return vehicle_business_use;
	}


	public void setVehicle_business_use(String vehicle_business_use) {
		this.vehicle_business_use = vehicle_business_use;
	}


	public String getVehicle_zip() {
		return vehicle_zip;
	}


	public void setVehicle_zip(String vehicle_zip) {
		this.vehicle_zip = vehicle_zip;
	}


	public String getVehicle_ownership() {
		return vehicle_ownership;
	}


	public void setVehicle_ownership(String vehicle_ownership) {
		this.vehicle_ownership = vehicle_ownership;
	}


	public String getVehicle_owned_years() {
		return vehicle_owned_years;
	}


	public void setVehicle_owned_years(String vehicle_owned_years) {
		this.vehicle_owned_years = vehicle_owned_years;
	}


	public String getVehicle_blindsopt() {
		return vehicle_blindsopt;
	}


	public void setVehicle_blindsopt(String vehicle_blindsopt) {
		this.vehicle_blindsopt = vehicle_blindsopt;
	}


	public List<Driver_Details> getDriver() {
		return driver;
	}


	public void setDriver(List<Driver_Details> driver) {
		this.driver = driver;
	}

	
	
	
}
