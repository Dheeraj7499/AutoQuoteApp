package com.spring.springmvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.springmvc.repo.RetrierveRepo;

@Controller
public class RetrieveContoller {
	
	@Autowired
	RetrierveRepo retrieve;
	
    @RequestMapping(value ="/Retrive.jsp")
	public String home1() {
		return "Retrive.jsp";
	}
    
    @RequestMapping(value ="retrieve")
 	public String retrieve() {
 		return "RetriveSummary.jsp";
 	}

}
