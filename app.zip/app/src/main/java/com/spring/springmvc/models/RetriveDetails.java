package com.spring.springmvc.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class RetriveDetails {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int retrieve_lastname;
	private int retrieve_email;
	private int retrieve_dob;
	private int retrieve_zipcode;
	
	public RetriveDetails() {
		
	}
	
	public RetriveDetails(int id, int retrieve_lastname, int retrieve_email, int retrieve_dob, int retrieve_zipcode) {
		super();
		this.id = id;
		this.retrieve_lastname = retrieve_lastname;
		this.retrieve_email = retrieve_email;
		this.retrieve_dob = retrieve_dob;
		this.retrieve_zipcode = retrieve_zipcode;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRetrieve_lastname() {
		return retrieve_lastname;
	}
	public void setRetrieve_lastname(int retrieve_lastname) {
		this.retrieve_lastname = retrieve_lastname;
	}
	public int getRetrieve_email() {
		return retrieve_email;
	}
	public void setRetrieve_email(int retrieve_email) {
		this.retrieve_email = retrieve_email;
	}
	public int getRetrieve_dob() {
		return retrieve_dob;
	}
	public void setRetrieve_dob(int retrieve_dob) {
		this.retrieve_dob = retrieve_dob;
	}
	public int getRetrieve_zipcode() {
		return retrieve_zipcode;
	}
	public void setRetrieve_zipcode(int retrieve_zipcode) {
		this.retrieve_zipcode = retrieve_zipcode;
	}

	@Override
	public String toString() {
		return "RetriveDetails [id=" + id + ", retrieve_lastname=" + retrieve_lastname + ", retrieve_email="
				+ retrieve_email + ", retrieve_dob=" + retrieve_dob + ", retrieve_zipcode=" + retrieve_zipcode + "]";
	}
	
	
	
	
	

}
