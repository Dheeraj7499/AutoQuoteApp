package com.spring.springmvc.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Basic_Details {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int ID;
	
	private String first_name;
	private String middle_name;
	private String last_name;
	private String suffix;
	private String mailing_addess;
	private String apt_number;
	private String city;
	private String state;
	private int zipcode;
	private String Gender;
	private String pobox;
	@OneToOne(mappedBy = "basicdetails")
	private SnapshotDetails snapshot;
	
	public Basic_Details() {
		
	}
	
	public Basic_Details(String first_name, String middle_name, String last_name, String suffix, String mailing_addess,
			String city, String state, int zipcode,String pobox) {
		super();
		this.first_name = first_name;
		this.middle_name = middle_name;
		this.last_name = last_name;
		this.suffix = suffix;
		this.mailing_addess = mailing_addess;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
		this.pobox = pobox;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getMiddle_name() {
		return middle_name;
	}

	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getMailing_addess() {
		return mailing_addess;
	}

	public void setMailing_addess(String mailing_addess) {
		this.mailing_addess = mailing_addess;
	}

	public String getApt_number() {
		return apt_number;
	}

	public void setApt_number(String apt_number) {
		this.apt_number = apt_number;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getZipcode() {
		return zipcode;
	}

	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String isPobox() {
		return pobox;
	}

	public void setPobox(String pobox) {
		this.pobox = pobox;
	}

	public SnapshotDetails getSnapshot() {
		return snapshot;
	}

	public void setSnapshot(SnapshotDetails snapshot) {
		this.snapshot = snapshot;
	}

	
	
	
	
}
