window.addEventListener('load', () => {

const first = sessionStorage.getItem('FirstName');
document.getElementById('driver_first_name').value = first;

const middle = sessionStorage.getItem('MiddleName');
document.getElementById('driver_middle_name').value = middle;

const last = sessionStorage.getItem('LastName');
document.getElementById('driver_last_name').value = last;

const addressdriver = sessionStorage.getItem('Address');
document.getElementById('driver_address').value = addressdriver;

})