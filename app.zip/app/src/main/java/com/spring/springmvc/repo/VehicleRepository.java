package com.spring.springmvc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.springmvc.models.Vehicle_Details;

public interface VehicleRepository extends JpaRepository<Vehicle_Details, Integer> {

}
