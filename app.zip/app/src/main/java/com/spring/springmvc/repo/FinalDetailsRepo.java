package com.spring.springmvc.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.springmvc.models.FinalDetails;

public interface FinalDetailsRepo extends JpaRepository<FinalDetails, Long>{
	

}
