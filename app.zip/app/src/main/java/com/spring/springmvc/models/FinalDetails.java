package com.spring.springmvc.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class FinalDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	private String existing_auto_insurance;
	private String years_long_existing_insurance;
	private String current_bodily_injury_limits;
	private String non_auto_policies_progressive;
	private String auto_insurance_progressive_last_month;
	private String reason_quoting_new_policy;
	private String residents_in_home;
	private String email;
	@OneToOne
	private Basic_Details basic_details;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getExisting_auto_insurance() {
		return existing_auto_insurance;
	}
	public void setExisting_auto_insurance(String existing_auto_insurance) {
		this.existing_auto_insurance = existing_auto_insurance;
	}
	public String getYears_long_existing_insurance() {
		return years_long_existing_insurance;
	}
	public void setYears_long_existing_insurance(String years_long_existing_insurance) {
		this.years_long_existing_insurance = years_long_existing_insurance;
	}
	public String getCurrent_bodily_injury_limits() {
		return current_bodily_injury_limits;
	}
	public void setCurrent_bodily_injury_limits(String current_bodily_injury_limits) {
		this.current_bodily_injury_limits = current_bodily_injury_limits;
	}
	public String getNon_auto_policies_progressive() {
		return non_auto_policies_progressive;
	}
	public void setNon_auto_policies_progressive(String non_auto_policies_progressive) {
		this.non_auto_policies_progressive = non_auto_policies_progressive;
	}
	public String getAuto_insurance_progressive_last_month() {
		return auto_insurance_progressive_last_month;
	}
	public void setAuto_insurance_progressive_last_month(String auto_insurance_progressive_last_month) {
		this.auto_insurance_progressive_last_month = auto_insurance_progressive_last_month;
	}
	public String getReason_quoting_new_policy() {
		return reason_quoting_new_policy;
	}
	public void setReason_quoting_new_policy(String reason_quoting_new_policy) {
		this.reason_quoting_new_policy = reason_quoting_new_policy;
	}
	public String getResidents_in_home() {
		return residents_in_home;
	}
	public void setResidents_in_home(String residents_in_home) {
		this.residents_in_home = residents_in_home;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Basic_Details getBasic_details() {
		return basic_details;
	}
	public void setBasic_details(Basic_Details basic_details) {
		this.basic_details = basic_details;
	}
	
	
}		
		